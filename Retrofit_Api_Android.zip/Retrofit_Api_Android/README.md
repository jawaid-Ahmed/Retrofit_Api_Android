# Retrofit_Api_Android
This project consists of examples of api's call through retrofit library
